import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

// Here we are doing command line game of tic tac toe. No rules just need to use loops for validation
// Game must continue for however long the user wants

public class HW08P02 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("\t\t ~ Welcome to TIC TAC TOE ~  ");

		// String variables and game counter
		final String USER_MENU = 
			" Select your object: \n" +
			" 1) Rock  \n" +
			" 2) Paper \n" +
			" 3) Scissors \n" +
			" 4) Exit... \n";

		final String COMPUTER_ROCK = 
			" The computer shoots Rock!";

		final String COMPUTER_PAPER = 
			" The computer shoots Paper!";

		final String COMPUTER_SCISSORS = 
			" The computer shoots Scissors!";



		final String ERROR_TEXT =
			" Invalid input detected... please try again and select a valid option. ";

		int userWins, computerWins, ties;
		userWins = 0;
		computerWins = 0;
		ties = 0;


		while (true) {
			System.out.println(USER_MENU);
			int userInput = input.nextInt();
			int computerInput = (int) ((Math.random()*3) + 1);

			if (userInput == 4) {
				System.out.println("Ending game now...");
				System.out.println("The final scores were... ");
				System.out.print("User wins: " + userWins);
				System.out.print("\t Computer wins: " + computerWins);
				System.out.print("\t Ties: " + ties);
				System.exit(1);
			}


			if (userInput == computerInput) {
				switch (computerInput) {
					case 1:	System.out.println(COMPUTER_ROCK);
							break;
					case 2: System.out.println(COMPUTER_PAPER);
							break;
					case 3: System.out.println(COMPUTER_SCISSORS);
							break;

				}
				System.out.println(" This round is a tie!");
				System.out.println();
				ties += 1;
			}

			else if (userInput == 1 && computerInput == 3) {
				System.out.println(COMPUTER_SCISSORS);
				System.out.println(" You won this round!");
				System.out.println();
				userWins += 1;
			}

			else if (userInput == 1 && computerInput == 2) {
				System.out.println(COMPUTER_PAPER);
				System.out.println(" You lost this round!");
				System.out.println();
				computerWins += 1;
			}

			else if (userInput == 2 && computerInput == 1) {
				System.out.println(COMPUTER_ROCK);
				System.out.println(" You won this round!");
				System.out.println();
				userWins += 1;
			}

			else if (userInput == 2 && computerInput == 3) {
				System.out.println(COMPUTER_SCISSORS);
				System.out.println(" You lost this round!");
				System.out.println();
				computerWins += 1;
			}

			else if (userInput == 3 && computerInput == 1) {
				System.out.println(COMPUTER_ROCK);
				System.out.println(" You lost this round!");
				System.out.println();
				computerWins += 1;
			}

			else if (userInput == 3 && computerInput == 2) {
				System.out.println(COMPUTER_PAPER);
				System.out.println(" You won this round!");
				System.out.println();
				userWins += 1;
			}

			else {
				System.out.println(ERROR_TEXT);
				System.out.println();
			}

		}

		
	}
}
 

 

