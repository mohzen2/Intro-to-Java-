import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 // In this problem we are asking number of stores, then asking the sales each of them did
// Must be a postive number of stores and positive sales

public class HW08P03 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);
		int numberOfStores = 0;

		System.out.print("How many stores are there?: ");
		numberOfStores = input.nextInt();
		System.out.println();
		while (numberOfStores < 1) {
			System.out.println("ERROR: The number of stores must be a postive integer!");
			System.out.print("How many stores are there?: ");
			numberOfStores = input.nextInt();
			System.out.println();
		} 


		String storeSales = "";
		String tempStoreSales = "";
		int tempStoreSalesNumber = 0;
		for (int i = 1; i < (numberOfStores + 1); i++){
			System.out.print("Enter the total number of Sales for Store " + i + ": ");
			tempStoreSales = input.next();
			tempStoreSalesNumber = Integer.parseInt(tempStoreSales);

			while ((tempStoreSalesNumber < 0) || (tempStoreSalesNumber % 100 != 0)) {
				System.out.println("ERROR: Value must be a positive number divisible by 100!");
				System.out.print("Enter the total number of sales for Store " + i + ": ");
				tempStoreSales = input.next();
				tempStoreSalesNumber = Integer.parseInt(tempStoreSales);

			}

			storeSales += tempStoreSales;


			if (i < (numberOfStores)) {
				storeSales += " ";
			}
		}

		// From here I have gathered the user input into a string of numbers with spaces inbetween the inputs
		// Now we have to convert and calculate the numbers from this string, assuming this is where we need the nested loops

		int spaceIndexOne, spaceIndexTwo, temp, salesNumber, starNumber;
		salesNumber = 0;
		spaceIndexOne = 0;
		spaceIndexTwo = storeSales.indexOf(' ');

		System.out.println();
		System.out.println("GRAPH OF TOTAL SALES");
		System.out.println("(Each * = $100)");

		for (int i = 1; i < (numberOfStores + 1); i++) {

			if (spaceIndexTwo == -1) {
				salesNumber = Integer.parseInt(storeSales.substring(spaceIndexOne));
			}

			if (spaceIndexTwo != -1 && i != 1) {
				salesNumber = Integer.parseInt((storeSales.substring(spaceIndexOne, spaceIndexTwo)));
				spaceIndexOne = spaceIndexTwo + 1;
				spaceIndexTwo = storeSales.indexOf(' ', spaceIndexOne);
			}

			if (i == 1) {
				if (spaceIndexTwo == -1) {
					salesNumber = Integer.parseInt(storeSales.substring(spaceIndexOne));
				}
				else {
					salesNumber = Integer.parseInt((storeSales.substring(spaceIndexOne, spaceIndexTwo)));
					spaceIndexOne = spaceIndexTwo + 1;
					spaceIndexTwo = storeSales.indexOf(' ', spaceIndexOne);
				}
			}

			//print statement and math
			System.out.print("Store " + i + ": ");
			starNumber = salesNumber / 100;

			for (int j = 0; j < starNumber; j++){
				System.out.print("*");
				if (j == (starNumber -1)) {
					System.out.println();
				}
			}
			//Rest the number
			starNumber = 0;
			
			


		}

		
		


	}
}