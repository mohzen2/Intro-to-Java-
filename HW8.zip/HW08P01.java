
/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 // ascii codes 33 to 126

public class HW08P01 {
	public static void main (String[] args) {
		int asciiCode = 33;
		int counter = 1;

		for (int i = 0; i < 94; i++) {
			char c = (char)asciiCode;
			if (counter % 10 == 0) 
				{ System.out.println(c); }
			else
				{ System.out.print(c); }

			asciiCode++;
			counter++;


		}
	}
}