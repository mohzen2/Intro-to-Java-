import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 // Here we are doing two simple patterns so lets start on the first one

public class HW08P04 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

		int patternOne, tempOne;
		System.out.print("How many rows for pattern one?: ");
		patternOne = input.nextInt();
		tempOne = patternOne;

		while(patternOne < 1 || patternOne > 999) {
			System.out.println("ERROR: Row amount must be a value between 1 and 999.");
			System.out.print("How many rows for pattern one?: ");
			patternOne = input.nextInt();
			tempOne = patternOne;
		}


		for (int i = 1; i < patternOne + 1; i++){
			tempOne = patternOne;
			for (int j = 0; j < i; j++){
				System.out.printf("%4d",tempOne);
				tempOne --;
			}
			System.out.println();
		}

		
		//Now well do pattern two, same as one but well be alternating between lower and uppercase ascii
		int patternTwo, tempTwo, upperCaseAscii, lowerCaseAscii;

		System.out.print("How many rows for pattern two?: ");
		patternTwo = input.nextInt();
		tempTwo = patternTwo;

		while(patternTwo < 1 || patternTwo > 26) {
			System.out.println("ERROR: Row amount must be a value between 1 and 26.");
			System.out.print("How many rows for pattern two?: ");
			patternTwo = input.nextInt();
			tempTwo = patternTwo;
		}

		for (int i = 1; i < patternTwo + 1; i++){
			
			char lowerCaseLetter = 'b';
			char upperCaseLetter = 'A';

			for (int j = 1; j < tempTwo + 1; j++){
				
				if (j % 2 == 0) {
					//Character lowerCaseLetter = (Character)(lowerCaseAscii);
					System.out.printf("%3c", lowerCaseLetter);
					lowerCaseLetter+=2;
				}
				else {
					//Character upperCaseLetter = (Character)(upperCaseAscii);
					System.out.printf("%3c", upperCaseLetter);
					upperCaseLetter+=2;
				}
			}
			System.out.println();
			tempTwo--;
		}







	}
}