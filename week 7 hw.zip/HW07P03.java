import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW07P03 {
 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);

 		// First thing is to gather the user input string than perform our checks
 		System.out.print("Enter a String: ");
 		String userInput = input.nextLine();
 		String uppercase = "";
 		String vowelReplaced = "";
        String indexOfVowels = "";
        int vowelCount, consonantCount;
        vowelCount = 0;
        consonantCount = 0;

 		for (int i = 0; i < userInput.length(); i++) {
 			if (Character.isUpperCase(userInput.charAt(i))) {
 				uppercase += userInput.charAt(i);
 				uppercase += " ";
 			}
 		}

 		for (int i = 0; i < userInput.length(); i++) {
 			if (userInput.charAt(i) == 'a' || userInput.charAt(i) == 'e' || userInput.charAt(i) == 'i' || userInput.charAt(i) == 'o' || userInput.charAt(i) == 'u' || userInput.charAt(i) == 'A' || userInput.charAt(i) == 'E' || userInput.charAt(i) == 'I' || userInput.charAt(i) == 'O' || userInput.charAt(i) == 'U' ) {
 				vowelReplaced += "_";
                vowelCount += 1;
                indexOfVowels += i;
                indexOfVowels += " ";
 			}
 			else {
 				vowelReplaced += userInput.charAt(i);
                if (Character.isLetter(userInput.charAt(i))) {
                    consonantCount += 1;
                }

 			}
 		}

 		System.out.println("");
 		System.out.println("Uppercase Letters: \t" + uppercase);
 		System.out.println("Vowels replaced: \t" + vowelReplaced);
        System.out.println("Number of vowels: \t" + vowelCount);
        System.out.println("Number of consonants: \t" + consonantCount);
        System.out.println("Positions of vowels: \t" + indexOfVowels);


 	}
 }