import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW07P04 {
 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);

 		// Put string outside of loop and initialize variables
 		System.out.print("Enter positive integers (-1 to finish): ");
 		String userInput = "";
 		int largest, smallest, odds, evens, userValue;
 		smallest = 2147483647;
 		largest = 0;
 		odds = 0;
 		evens = 0;

        // Couldnt think of a way to incorporate the check into the while statement
        // At first i put !userInput.equals("-1") in the while loop
        // but that led to -1 being compared before quiting so i just changed it to this. Feels wrong but it works

 		while (true) {
 			userInput = input.next();
            if (userInput.equals("-1")) 
                { break; }

 			userValue = Integer.parseInt(userInput);
 			if (userValue > largest) 
                { largest = userValue; }
 			if (userValue < smallest) 
 				{ smallest = userValue; }
 			if ((userValue % 2) == 0) 
 				{ evens +=1; }
 			else 
 				{ odds +=1; }

 		} 

 		System.out.println("");
 		System.out.println("Largest value: \t\t" + largest);
 		System.out.println("Smallest value: \t" + smallest);
 		System.out.println("Total Even Values: \t" + evens);
 		System.out.println("Total odd values: \t" + odds);


 	}
 }