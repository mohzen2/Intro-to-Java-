import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW07P02{
 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);

        // First things first gather user input to initialize
        System.out.print("Enter values (x to end): ");
        String userInput = "";
        double userValue, count, mean, deviation, squares;
        count = 0;
        mean = 0;
        squares = 0;


        do {
            // The loop will continue until x is entered

            userInput = input.next();
            if (userInput.equals("x")) {
                break;
            }
            else
            {
            userValue = Double.parseDouble(userInput);
            mean += userValue;
            squares += Math.pow(userValue, 2);


            count++;
            } 
        } while (!userInput.equals("x"));

        deviation = Math.pow(((squares - (Math.pow(mean, 2) / count)) / (count - 1)), 1.0/2.0);

        System.out.println("Average: " + (mean/count));
        System.out.println("Deviation: " + deviation);
        


 	}
 }