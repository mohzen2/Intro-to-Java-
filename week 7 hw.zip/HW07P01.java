import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW07P01 {
 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);

 		// First thing first gather our user input than validate this time with strings
 		System.out.print("Enter a social security number: ");
 		String userSSN = input.nextLine();
 		String invalid = " is not a valid number.";

 		// The most basic test just make sure the length is correct
 		if (userSSN.length() != 11) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		// now loop for numbers and dashes
		int count = 0;
		while (count <= 10) {

			if ((count != 3) && (count != 6)) {
				if (!Character.isDigit(userSSN.charAt(count))) {
					System.out.println(userSSN + invalid);
					System.exit(1);
				}
			}

			if (count == 3 || count == 6 ) {
				if ((userSSN.charAt(count) != '-')) {
					System.out.println(userSSN + invalid);
					System.exit(1);
				}
			}


			count ++;
		}

		System.out.println(userSSN + " is a valid number.");
		System.exit(1);




 	}
 }