import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW11P03{
 	public static void main(String[] args){
 		Scanner input = new Scanner(System.in);
 		System.out.print("How many random values?: ");
 		int userInput = input.nextInt();
 		int[] returnedArray = new int[userInput];
 		System.arraycopy(arrayGenerator(userInput), 0, returnedArray, 0, userInput);

        String[] matchedArray2 = new String[userInput];
        System.arraycopy(matchedArray(returnedArray, userInput), 0, matchedArray2, 0, userInput); 

        System.out.println();
 		for(int i = 0; i < userInput; i++){
 			System.out.print(matchedArray2[i]);
 		}
 	}

 	public static int[] arrayGenerator(int n){
 		int[] array = new int[n];
 		for(int i = 0; i < n; i++){
 			array[i] = (int)(Math.random() * 4) + 1;
 		}
 		return array;
 	}

 	public static String[] matchedArray(int[] array, int n){
        int gate = 0; // Here we will use this as a switch to check the parentheses positions.
 		String[] matchedArray = new String[n];
 		for (int i = 0; i < array.length-1 ; i++){
 			if (array[i] == array[i+1]){
                if(gate == 0){
                    matchedArray[i] = "(" + Integer.toString(array[i]) + " ";
                    gate = 1;
                    continue;
                }
                if(gate == 1){
                    matchedArray[i] = Integer.toString(array[i]) + " ";
                }
 			}
            if (array[i] != array[i+1]){
                if(gate == 0){
                    matchedArray[i] = Integer.toString(array[i]) + " "; 
                }
                if(gate == 1){
                    matchedArray[i] = Integer.toString(array[i]) + ") ";
                    gate = 0;
                }
            }
 		}

        if(array[n-1] == array[n-2]){
            if(gate == 1){
                matchedArray[n-1] = Integer.toString(array[n-1]) + ")";
            }
        }
        if(array[n-1] != array[n-2]){
            matchedArray[n-1] = Integer.toString(array[n-1]);
        }


        return matchedArray;
 	}


 }