import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW11P01 {
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");
        int userInput = input.nextInt();
        int[] userArray = arrayGenerator(userInput);

        System.out.println();
        printArray(userArray);
        printEvenArray(userArray);
        printOddElements(userArray);
        printReverseArray(userArray);
        printFMLArray(userArray);

    }

    public static int[] arrayGenerator(int n){
        int[] randomArray = new int[n];
        for(int i = 0; i < n; i++){
            randomArray[i] = (int) ((Math.random() * 20) + 1);
        }

        return randomArray;
    }

    public static void printArray(int[] array){
        System.out.print("Array: \t\t\t");
        for(int i = 0; i < array.length; i++){
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void printEvenArray(int[] array){
        System.out.print("Even Indexes: \t\t");
        for(int i = 0; i < array.length; i+=2){
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void printOddElements(int[] array){
        System.out.print("Odd elements: \t\t");
        for(int i = 0; i < array.length; i++){
            if(array[i] % 2.0 == 1){
                System.out.print(array[i] + " ");
            }
        }
        System.out.println();
    }

    public static void printReverseArray(int[] array){
        System.out.print("Reverse: \t\t");
        for(int i = (array.length - 1); i >= 0; i--){
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void printFMLArray(int[] array){
        System.out.print("First, Middle, Last: \t");
        int length = array.length;
        int round = Math.round(array.length / 2);
        System.out.print(array[0] + " ");
        if(array.length % 2.0 == 0){
            System.out.print(array[(length/2) - 1] + " ");
            System.out.print(array[(length/2) ] + " ");
        }
        else{
            System.out.print(array[round] + " ");
        }

        System.out.print(array[length - 1]);
        System.out.println();

    }



}