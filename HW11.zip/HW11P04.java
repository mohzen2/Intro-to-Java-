import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW11P04{
    static Scanner input = new Scanner(System.in);
 	public static void main(String[] args){
        System.out.print("How many scores are there?: ");
        int userInput = input.nextInt();

        double[] returnedArray = new double[userInput];
        System.arraycopy(arrayGenerator(userInput), 0, returnedArray, 0, userInput);

        double bestScore = findBest(returnedArray, userInput);
        //System.out.print(bestScore);

        printGrade(returnedArray, bestScore);
    }

    public static double[] arrayGenerator(int n){
        double[] array = new double[n];
        System.out.println();
        System.out.print("Enter the scores: ");
        for(int i = 0; i < n; i++){
            array[i] = input.nextDouble();
        }
        return array;
    }

    public static double findBest(double[] array, int n){
        double bestScore = 0;
        for(int i = 0; i < n; i++){
            if(array[i] > bestScore){
                bestScore = array[i];
            }
        }
        return bestScore;
    }

    public static void printGrade(double[] array, double best){
        System.out.println();
        System.out.println("The best score is: " + best);
        System.out.println();
        for(int i = 0; i < array.length; i++){
            System.out.print("Student " + (i + 1) + " score is " + array[i] + " and grade is: ");
            if(array[i] >= (best-15)){
                System.out.println("A");
                continue;
            }
            if(array[i] >= (best-25)){
                System.out.println("B");
                continue;
            }
            if(array[i] >= (best-35)){
                System.out.println("C");
                continue;
            }
            if(array[i] >= (best-45)){
                System.out.println("D");
                continue;
            }
            else{
                System.out.println("F");
                continue;
            }
        }
    }
 }