import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW11P02 {
    public static void main (String[] args){
        String[] nouns = {"area", "book","business", "case", "child", "company", "country", "day", "eye", "fact", "family", "government", "group", "hand", "home", "job", "life", "lot", "man", "money", "night", "number", "part", "people", "place", "point", "problem", "program", "question", "right"};
        String[] adjectives = {"other", "new", "good", "high", "old", "great", "big", "American", "small", "large", "national", "young", "different", "dark", "long", "little", "important", "political", "bad", "light", "real", "best", "correct", "social", "only", "public", "sure", "low", "early", "able"};
        String[] verbs = {"be", "have", "do", "say", "get", "make", "go", "know", "take", "see", "come", "think", "look", "want", "give", "use", "find", "tell", "ask", "work", "seem", "feel", "try", "leave", "call", "run", "jump", "yell", "scream", "cry"};
        String[] prepositions = {"of", "in", "to", "for", "with", "on", "at", "from", "by", "about", "as", "into", "like", "through", "after", "over", "between", "out", "against", "during"};
        String[] articles = {"the", "a"};

        System.out.println("Your randomly generated sentences are...");
        System.out.println();
        for (int i = 0; i < 7; i++){
            System.out.println(stringGenerator(nouns, adjectives, verbs, prepositions, articles));
        }
    }

    public static String stringGenerator(String[] nouns, String[] adjectives, String[] verbs, String[] prepositions, String[] articles){
        String randomString = "";
        
        randomString += capitalize(articles[random2()]);
        randomString += " ";
        randomString += adjectives[random30()];
        randomString += " ";
        randomString += nouns[random30()];
        randomString += " ";
        randomString += verbs[random30()];
        randomString += " ";
        randomString += prepositions[random20()];
        randomString += " ";
        randomString += articles[random2()];
        randomString += " ";
        randomString += adjectives[random30()];
        randomString += " ";
        randomString += nouns[random30()];
        randomString += ".";

        return randomString;

    }

    public static int random30(){
        int randomNumber = (int) (Math.floor(Math.random() * 30));
        return randomNumber;
    }

    public static int random20(){
        int randomNumber = (int) (Math.floor(Math.random() * 20));
        return randomNumber;
    }

    public static int random2(){
        int randomNumber = (int) (Math.round(Math.random() ));
        return randomNumber;
    }

    public static String capitalize(String word){
        if(word.length() < 3){
            String recapitalize1 = word.substring(0).toUpperCase();
            return recapitalize1;
        }
        else {
            String recapitalize2 = word.substring(0,1).toUpperCase() + word.substring(1);
            return recapitalize2;
        }

    }

    
}