import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW02P02 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter the diameter of the pizza (inches): ");
        int diameter = input.nextInt();
        
        double radius = (diameter/2.0);
        double area = (Math.PI * Math.pow(radius, 2));
        int slices = (int)(area / 14.125);

        System.out.println();    
        System.out.println("A pizza with diameter of "+ diameter +" can be cut into "+ slices +" slices.");


    }
}
