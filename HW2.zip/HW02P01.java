import java.util.Scanner;
/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW02P01 {
	public static void main (String[] args) {

		double product1, product2, product3, product4, product5, subtotal, total;

		final double tax = 0.09;

		Scanner input = new Scanner(System.in);

		System.out.print("Enter the cost of product 1: ");
		product1 = input.nextDouble();

		System.out.print("Enter the cost of product 2: ");
		product2 = input.nextDouble();

		System.out.print("Enter the cost of product 3: ");
		product3 = input.nextDouble();

		System.out.print("Enter the cost of product 4: ");
		product4 = input.nextDouble();

		System.out.print("Enter the cost of product 5: ");
		product5 = input.nextDouble();

		subtotal = product1 + product2 + product3 + product4 + product5;


		System.out.println();
		System.out.println("-------------Sales Receipt-------------");
		System.out.println();

		System.out.println("Product 1......................$"+ product1);
		System.out.println("Product 2......................$"+ product2);
		System.out.println("Product 3......................$"+ product3);
		System.out.println("Product 4......................$"+ product4);
		System.out.println("Product 5......................$"+ product5);
		System.out.println();

		System.out.println("Subtotal.......................$"+ subtotal);
		System.out.println("Sales Tax......................$"+ (subtotal * tax));
		System.out.println("Total..........................$"+(subtotal+(subtotal*tax)));
		System.out.println();
		System.out.println("---------------------------------------");
















	}
}