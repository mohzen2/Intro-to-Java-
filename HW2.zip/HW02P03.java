import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW02P03 {
 	public static void main (String[] args) {

 		Scanner input = new Scanner(System.in);

 		

 		System.out.print("Enter a temperature in Fahrenheit betweem -58F and 41F: ");
 		double outsideTemperature = input.nextDouble();

 		System.out.print("Enter a wind speed greater than or equal to 2 in miles per hour: ");
 		double outsideWindSpeed = input.nextDouble();
 		outsideWindSpeed = Math.pow(outsideWindSpeed, 0.16);

 		double windChill = (35.74 + (0.6215 * outsideTemperature) - (35.75 * outsideWindSpeed) + (0.4275 * outsideTemperature * outsideWindSpeed));

 		System.out.print("The wind chill temperature is " + windChill);

 	}
 }