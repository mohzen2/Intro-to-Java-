import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW09P02 {

 	public static void main (String[] args){
 		double length = readLength();
 		double width = readWidth();
 		double solution = computeArea(length, width);
 		displaySolution(solution);

 	}

 	public static double readLength () {
 		System.out.print("Enter the length of the rectangle: ");
 		Scanner input = new Scanner(System.in);
 		double length = input.nextDouble();

 		while (length < 0) {
 			System.out.print("Please enter a non-negative value for the length: ");
 			length = input.nextDouble();
 		}

 		return length;

 	}

 	public static double readWidth () {
 		System.out.print("Enter the width of the rectangle: ");
 		Scanner input = new Scanner(System.in);
 		double width = input.nextDouble();

 		while (width < 0) {
 			System.out.print("Please enter a non-negative value for the width: ");
 			width = input.nextDouble();
 		}

 		return width;

 	}

 	public static double computeArea (double length, double width) {
 		double area = length * width;
 		return area;

 	}
 	public static void displaySolution (double solution) {
 		System.out.println("The area of the rectangle is: " + solution);

 	}
 }