import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW09P01 {
 	// In this assingment we are practicing our use of methods so we will seperate the calulations into the method
 	// and call the method in the main

 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);
 		System.out.print("Enter a value for n: ");
 		int userInput = input.nextInt();

 		while (userInput <= 0) {
 			System.out.print("ERROR: Please input a valid integer: ");
 			userInput = input.nextInt();
 		}

 		printMatrix(userInput);
 	}


 	public static void printMatrix (int n){
 		// This method is void so it will not return anything we will feed it an int, print our matrix and then finish.
 		// We are printing an n x n matrix of random ones and zeros. So after gathering the n we will use nested loops
 		for (int i = 0; i < n; i++){
 			for (int j = 0; j < n; j++){
 				int number = (int) ( Math.round( Math.random() ) );
 				System.out.print(number);
 				System.out.print(" ");
 			}
 			System.out.println();
 		}

 	}
 }