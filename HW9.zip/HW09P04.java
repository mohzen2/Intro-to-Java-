import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW09P04 {

	public static void main (String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the size of the grid: ");
		double userInput = input.nextDouble();
		String rows = rowGenerator(userInput);
		String columns = columnGenerator(userInput);
		printMatrix(rows, columns, userInput);

	}

	public static String rowGenerator(double rowNumber){
		String rows = "";
		for (int i = 0; i < rowNumber; i++){
			if (i == 0) {
				rows += "+--+";
			}
			else {
				rows += "--+";
			}
		}
		return rows;

	}

	public static String columnGenerator(double columnNumber){
		String columns = "";
		for (int i = 0; i < columnNumber; i++){
			if (i == 0) {
				columns += "|  |";
			}
			else {
				columns += "  |";
			}
		}
		return columns;
	}

	public static void printMatrix(String rows, String columns, double userInput){
		for (int i = 0; i < userInput; i++)
			if (i == 0) {
				System.out.println(rows);
				System.out.println(columns);
				System.out.println(rows);
			}
			else {
				System.out.println(columns);
				System.out.println(rows);
			}
	}
}