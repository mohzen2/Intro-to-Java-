import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW09P03 {
    
    static double quizScore;
    static double quizAverage;
    static double lowest;
    static double lowest2;
    static Scanner input = new Scanner(System.in);
    static double counter;

 	public static void main (String[] args) {
        quizScore = 0;
        counter = 0;
        lowest = 100;
        lowest2 = 100;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the ten test scores: ");
        for (int i = 0; i < 10; i++){
            double temp = readQuizScore();
            quizScore += temp;
            lowest = getLowestScore(temp);
            counter++;
        }
        System.out.println();
        System.out.println("Two lowest scores: " + lowest + " and " + lowest2);
        System.out.print("Average: ");
        System.out.printf("%.2f", computeAverage(quizScore));
 	}

 	public static double readQuizScore() {
        
        double testScore = input.nextDouble();

        while (testScore < 0 || testScore > 100) {
            System.out.println("ERROR: Test score must be a valid number between 0.0 and 100.0");
            System.out.print("Please enter a valid input: ");
            testScore = input.nextDouble();
        }
        return testScore;
 	}

 	public static double computeAverage(double quizScore) {
        quizAverage = quizScore / 10.0;
        return quizAverage;
 	}

 	public static double getLowestScore(double quizScore){
        // we are making the assumption there will always be two lowest scores. Thus we offest the second lowest score and move them together as two pointers.
        if (quizScore < lowest) {
            if (counter > 0) {
                lowest2 = getSecondLowestScore(lowest);
            }
            lowest = quizScore;
        }
        if (quizScore > lowest && quizScore < lowest2 ) {
            lowest2 = getSecondLowestScore(quizScore);
        }
       return lowest;
 	}

 	public static double getSecondLowestScore(double quizScore){
        if (quizScore < lowest2) {
            lowest2 = quizScore;
        }
        return lowest2;
    }



 }