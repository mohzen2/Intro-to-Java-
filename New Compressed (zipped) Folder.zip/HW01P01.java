/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05/06>
 * Description: <Introductory programming and principles with java>
 */
public class HW01P01 {
    public static void main(String[] args) {
        double radius = 10.493;
        double area = Math.PI * radius * radius;
        double circ = 2* Math.PI * radius;

        System.out.println("The area of a circle with radius 10.493 is: "+ area);
        System.out.println("The circumference of a circle with radius 10.493 is: "+ circ);

    }
}