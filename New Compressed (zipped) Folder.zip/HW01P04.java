/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05/06>
 * Description: <Introductory programming and principles with java>
 */
public class HW01P04 {
    public static void main(String[] args) {

    System.out.println("                     ..    d$P              $$      `$b");
    System.out.println("                    z$\"   $$F               4$$      $$L");
    System.out.println("                    $$   4$$                 $$.     4$$    ,z$P");
    System.out.println("                    $$   $$\'                 $$F      $$   $$$P");
    System.out.println("                   $$$   $$                  $$f      $$   \"\"`");
    System.out.println("                  $\'$$; 4$F      .,_         $$\'      $$");
    System.out.println("                .$\' ?$L 4$\'   .d$\" `?    zee $$   ,ec $F  d$F z$$   ,ce,.");
    System.out.println("              .d$ee. $$ 4$\'  d$\"   z$  $$\"  .$f.d$\"  4$  4$$ 4$$P z$P?$$$");
    System.out.println("             d$\" \"?$$d$,`$  $$F   z$f,$$    $$.$$    $P  $$% $$$4$\"   4$$");
    System.out.println(".$\"%.     ,p$\"        $$ $ J$$  z$$$ $$\"  .$$ $$\"  .$$C 4$P  $$$\"     $$f");
    System.out.println("`$.     ,d$b****q,     $.$ $$$$$P $$.$$b.$P4$ $$L.$P4$F $P  4$P     .$$\"");
    System.out.println(" `?$$g$P\"        \"     `b' `??\"   \"?\"^?F\"   $$`?PF\"  $$ \"   P'     eF");
    }
}