/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05/06>
 * Description: <Introductory programming and principles with java>
 */
public class HW01P03 {
    public static void main(String[] args) {
        System.out.println("Do not go gentle into that good night");
        System.out.println("Dylan Thomas");
        System.out.println();
        System.out.println("Do not go gentle into that good night,");
        System.out.println("Old age should burn and rave at close of day;");
        System.out.println("Rage, rage against the dying of the light.");
        System.out.println();
        System.out.println("Though wise men at their end know dark is right,");
        System.out.println("Because their words had forked no lightning they");
        System.out.println("Do not go gentle into that good night.");
        System.out.println();
        System.out.println("Good men, the last wave by, crying how bright");
        System.out.println("Their frail deeds might have danced in a green bay,");
        System.out.println("Rage, rage against the dying of the light.");
        System.out.println();
        System.out.println("Wild men who caught and sang the sun in flight,");
        System.out.println("And learn, too late, they grieved it on its way,");
        System.out.println("Do not go gentle into that good night.");
        System.out.println();
        System.out.println("Grave men, near death, who see with blinding sight");
        System.out.println("Blind eyes could blaze like meteors and be gay,");
        System.out.println("Rage, rage against the dying of the light.");
        System.out.println();
        System.out.println("And you, my father, there on the sad height,");
        System.out.println("Curse, bless, me now with your fierce tears, I pray.");
        System.out.println("Do not go gentle into that good night.");
        System.out.println("Rage, rage against the dying of the light.");
        }
}