/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05/06>
 * Description: <Introductory programming and principles with java>
 */
public class HW01P02 {
    public static void main(String[] args) {
        int answer = 2 * 4 * 6 * 8 * 10 * 12 * 14 * 16 * 20;

        System.out.println("2 * 4 * 6 * 8 * 10 * 12 * 14 * 16 * 20 = "+ answer);
        }
}