import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW06P04 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

		//First thing is to get username and command
		System.out.print("Enter your character name: ");
		String username = input.nextLine();

		System.out.print("> ");
		String userInput = input.nextLine();

		// Basic input validation just to make sure it starts with a slash.
		if (!userInput.startsWith("/")) {
			System.out.println("Sorry that is an invalid command. Please try a valid /slash command. Program exiting now...");
			System.exit(1);
		}

		// Performining input simplification for switch statement
		String userCommand = "";
		if (userInput.startsWith("/roll")) {
			userCommand = "/roll";
		}
		else if (userInput.startsWith("/dance")) {
			userCommand = "/dance";
		}
		else if (userInput.startsWith("/invite")) {
			userCommand = "/invite";
		}
		else if (userInput.startsWith("/say")) {
			userCommand = "/say";
		}

		// do some sort of indexing trick for invites and says


		// Now we will perform the slash commands

		switch (userCommand) {
			case "/roll":
				System.out.println("> " + username + " rolled a " + ((int)(Math.random() * 101)) + ".");
				System.exit(1);
				break;

			case "/dance":
				System.out.println("> " + username + " performs a lively dance.");
				System.exit(1);
				break;

			case "/invite":
				if ( (userInput.length() <= 8) || (((userInput.substring(8)).trim()).length() == 0) ) {
					System.out.println("Error: Please enter a valid username to invite. Program exiting now...");
					System.exit(1);
					break;
				} 
				
				System.out.println("> " + userInput.substring(8) + " has been invited to " + username + "'s party.");
				System.exit(1);
				break;

			case "/say":
				if ( (userInput.length() <= 5) || (((userInput.substring(5)).trim()).length() == 0) ) {
					System.out.println("Error: Please enter a valid /say command. Program exiting now...");
					System.exit(1);
					break;
				} 
				System.out.println("> " + username + " says: " + userInput.substring(5));
				System.exit(1);
				break;

			default :
				System.out.println("Sorry that appears to be an invalid command. Please try a valid /slash command. Program exiting now...");
				System.exit(1);
				break;

		}
		



	}
}


