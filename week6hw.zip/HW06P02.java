import java.util.Random;
/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW06P02 {
    public static void main (String[] args) {
        // We will create a license number generator. No input needed just three uppercase letters and four numbers
        Random r = new Random();

        char letter1 = (char)(r.nextInt(26) + 65);
        char letter2 = (char)(r.nextInt(26) + 65);
        char letter3 = (char)(r.nextInt(26) + 65);
        int number1 = r.nextInt(10);
        int number2 = r.nextInt(10);
        int number3 = r.nextInt(10);
        int number4 = r.nextInt(10);
        String licenseString = "Your license plate number is: ";
        System.out.println(licenseString + letter1 + letter2 + letter3 + number1 + number2 + number3 + number4);
    }
}