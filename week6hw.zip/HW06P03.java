import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW06P03 {
	public static void main (String[] args) {
		// create scanner object
		Scanner input = new Scanner(System.in);

		System.out.print("Enter a social security number: ");

		String userSSN = input.nextLine();
		String invalid = " is not a valid number.";

		if (userSSN.length() != 11) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(0))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(1))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(2))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (userSSN.charAt(3) != '-') {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(4))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(5))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (userSSN.charAt(6) != '-') {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(7))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(8))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(9))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else if (!Character.isDigit(userSSN.charAt(10))) {
			System.out.println(userSSN + invalid);
			System.exit(1);
		}

		else {
			System.out.println(userSSN + " is a valid number.");
			System.exit(1);
		}



		
	}
}