import java.util.Scanner;


/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */


public class HW06P01 {
    public static void main (String[] args) {
        Scanner input = new Scanner(System.in);

        // First gather user input
        System.out.println();
        String userInputOne, userInputTwo;
        System.out.print("Enter the first string: ");
        userInputOne = input.nextLine();
        System.out.print("Enter the second string: ");
        userInputTwo = input.nextLine();

        // We count the number of characters in each string
        System.out.println();
        System.out.println("\"" + userInputOne + "\"" + " has " + userInputOne.length() + " characters.");
        System.out.println("\"" + userInputTwo + "\"" + " has " + userInputTwo.length() + " characters.");
        System.out.println();

        // Check wether the strings are substrings of one and other
        // First we'll check string one against string two
        // We need to make both strings the same Case for all of the following comparisons and checks.
        String loweredStringOne = userInputOne.toLowerCase();
        String loweredStringTwo = userInputTwo.toLowerCase();

        // Equality check helps us maybe skip some steps or double check
        boolean substringEqualityCheck = loweredStringOne.equals(loweredStringTwo);
        boolean substringTwoContainCheck = loweredStringTwo.contains(loweredStringOne);
        boolean stringTwoBeginning = loweredStringTwo.startsWith(loweredStringOne);
        boolean stringTwoEnding = loweredStringTwo.endsWith(loweredStringOne);

        //first we check if the strings are complete matches or nothing in common at all
        if (substringEqualityCheck) {
            System.out.println("\"" + userInputOne + "\" is a substring of \"" + userInputTwo + "\" and appears at the beginning, middle, and end of the string.");
            System.out.println("\"" + userInputTwo + "\" is a substring of \""+ userInputOne + "\" and appears at the beginning, middle, and end of the string.");
        }
        else if (!substringTwoContainCheck) {
            System.out.println("\"" + userInputOne + "\" is not a substring of \"" + userInputTwo + "\".");
        }
        // if not we continue the checks
        else
            {System.out.print("\"" + userInputOne + "\" is a substring of \"" + userInputTwo + "\" and appears at the ");}
        if (stringTwoBeginning && !substringEqualityCheck) {
            if (stringTwoBeginning && stringTwoEnding) 
                { System.out.println("beginning and end of the string."); }
            else 
                { System.out.println("beginning of the string."); }
            }
        if (!stringTwoBeginning && !stringTwoEnding && substringTwoContainCheck) 
            { System.out.println("middle of the string." ); }
        else if (!stringTwoBeginning && stringTwoEnding && substringTwoContainCheck)
            { System.out.println("end of the string."); }


        // Now we do string two checks against string one should be all the same steps just skipping over the equality check

        boolean substringOneContainCheck = loweredStringOne.contains(loweredStringTwo);
        boolean stringOneBeginning = loweredStringOne.startsWith(loweredStringTwo);
        boolean stringOneEnding = loweredStringOne.endsWith(loweredStringTwo);

        if (!substringOneContainCheck) {
            System.out.println("\"" + userInputTwo + "\" is not a substring of \"" + userInputOne + "\".");
        }
        if (stringOneBeginning && !substringEqualityCheck) {
            if (stringOneBeginning && stringOneEnding) 
                { System.out.println("\"" + userInputTwo + "\" is a substring of \"" + userInputOne + "\" and appears at the beginning and end of the string."); }
            else
                {System.out.println("\"" + userInputTwo + "\" is a substring of \"" + userInputOne + "\" and appears at the beginning of the string.");}
        }
        if (!stringOneBeginning && !stringOneEnding && substringOneContainCheck)
            {System.out.println("\""+ userInputTwo + "\" is a substring of " + userInputOne + "\" and appears at the middle of the string."); }
        else if (!stringOneBeginning && stringOneEnding && substringOneContainCheck)
            {System.out.println("\"" + userInputTwo + "\" is a substring of " + userInputOne + "\" and appears at the end of the string.");}



        // Finally we are doing the equality of which string is greater
        System.out.println();
        int stringComparison = loweredStringTwo.compareToIgnoreCase(loweredStringOne);
        if (stringComparison == 0)
            {System.out.println("\"" + userInputOne + "\" and \"" + userInputTwo + "\" are equal." ); }
        else if (stringComparison > 0)
            { System.out.println("\"" + userInputOne + "\" and \"" + userInputTwo + "\" are not equal, \"" + userInputOne + "\" is alphabetically less than \"" + userInputTwo + "\"." ); }
        else if (stringComparison < 0)
            { System.out.println("\"" + userInputOne + "\" and \"" + userInputTwo + "\" are not equal, \"" + userInputOne + "\" is alphabetically greater than \"" + userInputTwo + "\"." );}


                










        


    }
}