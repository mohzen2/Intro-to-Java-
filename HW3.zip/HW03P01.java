import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW03P01 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

//Inputs
		System.out.print("Enter the length and width of the pyramid base: ");
		double length = input.nextDouble();
		double width = input.nextDouble();

		System.out.print("Enter the height of the pyramid: ");
		double height = input.nextDouble();

// Computation
		double baseArea = length * width;
		double volume = (1.0/3.0)* baseArea * height;

// Output
		System.out.println("Base Area: \t" + baseArea);
		System.out.println("Volume: \t" + volume);

	}
}

