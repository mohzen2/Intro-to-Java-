import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW03P04 {
    public static void main (String[] args) {

        // Declerations
        Scanner input = new Scanner(System.in);
        int  wholeNumber, firstDigit, secondDigit, thirdDigit, fourthDigit, fifthdigit, sumOfDigits;

        //Input
        System.out.print("Enter a five digit number: ");
        wholeNumber = input.nextInt();

        //Computations
        firstDigit = wholeNumber % 10;
        secondDigit = ((wholeNumber / 10) % 10);
        thirdDigit = ((wholeNumber / 100) % 10);
        fourthDigit = ((wholeNumber / 1000) % 10);
        fifthdigit = (wholeNumber / 10000);
        sumOfDigits = firstDigit + secondDigit + thirdDigit + fourthDigit + fifthdigit; 

        System.out.println();
        System.out.print("Sum of digits: " + sumOfDigits);





    }
}