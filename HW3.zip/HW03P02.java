import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW03P02 {
 	public static void main (String[] args) {


 		// Decleration and constants
 		Scanner input = new Scanner (System.in);

 		final int SPEED_5 = 5;
 		final int SPEED_10 = 10;
 		final int SPEED_15 = 15;

 		// Inputs
 		System.out.print("Enter the speed of the car (mph): ");

 		double actualSpeed = input.nextDouble();

 		// Calculations and output since its simple
 		System.out.println("Time (hours)\t\tDistance (miles)");
 		System.out.println("--------------------------------------");
 		System.out.println(SPEED_5 + "\t\t\t" + (SPEED_5 * actualSpeed));
 		System.out.println(SPEED_10 + "\t\t\t" + (SPEED_10 * actualSpeed));
 		System.out.println(SPEED_15 + "\t\t\t" + (SPEED_15 * actualSpeed));



 	}
 }