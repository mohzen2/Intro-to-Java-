import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW03P03 {
 	public static void main (String[] args) {

        // Declerations
        final int CLASS_A = 15;
        final int CLASS_B = 12;
        final int CLASS_C = 9;
        int ticketsA, ticketsB, ticketsC, totalSales;
 		Scanner input = new Scanner(System.in);

        // Inputs
        System.out.print("How many Class A tickets were sold?: ");
        ticketsA = input.nextInt();
        System.out.print("How many Class B tickets were sold?: ");
        ticketsB = input.nextInt();
        System.out.print("How many Class C tickets were sold?: ");
        ticketsC = input.nextInt();
        System.out.println();

        // Calculations and outputs

        totalSales = ((CLASS_A * ticketsA) + (CLASS_B * ticketsB) + (CLASS_C * ticketsC));

        System.out.println("Class A Total: $" + (CLASS_A * ticketsA));
        System.out.println("Class B Total: $" + (CLASS_B * ticketsB));
        System.out.println("Class C Total: $" + (CLASS_C * ticketsC));
        System.out.println();
        System.out.print("Total Sales: $" + totalSales);


 		
 	}
 }