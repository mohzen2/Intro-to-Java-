import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 // The main thing to remember is ONE TASK PER METHOD
public class HW10P03{
	static Scanner input = new Scanner(System.in);
    
	public static void main (String[] args){
		System.out.print("Enter the credit card number to check it's validity: ");
        String creditCardString = input.next();
        //System.out.println(brandCheck(creditCardString) + "brandCheck");
        //System.out.println(lengthCheck(creditCardString) + "lengthCheck");
        //System.out.println(arithmeticCheck(creditCardString) + "arithmeticCheck");
        validityCheck(creditCardString);
	}
    public static void validityCheck(String creditCardString){
        if (lengthCheck(creditCardString) && brandCheck(creditCardString) && arithmeticCheck(creditCardString)){
            System.out.println(creditCardString + " is a valid credit card number.");
        }
        else {
            System.out.println(creditCardString + " is not a valid credit card number.");
        }
    }

    public static boolean arithmeticCheck(String creditCardString){
        
        if ((odds(creditCardString) + evens(creditCardString)) % 10 == 0){
            return true;
        }
        return false;
    }

    public static int odds(String creditCardString){
        int odds = 0;
        int length = creditCardString.length();

        for (int i = (length - 1); i >= 0; i -= 2){
            String emptyString = "";
            emptyString += creditCardString.charAt(i);
            int number = Integer.parseInt(emptyString);
            odds += number;
        }
        //System.out.println(odds + "odds");
        return odds;
    }

    public static int evens(String creditCardString){
        int evens = 0;
        int length = creditCardString.length();

        for (int i = (length - 2); i >= 0; i -= 2){
            String emptyString = "";
            emptyString += creditCardString.charAt(i);
            int number = Integer.parseInt(emptyString);
            number = number * 2;
            if (number > 9) {
                evens += numberReducer(number);
            }
            else{
                evens += number;
            }
        }
        //System.out.println(evens + "evens");
        return evens;
    }

    public static int numberReducer(int n){
        String number = Integer.toString(n);
        String number1 = "";
        String number2 = "";
        number1 += number.charAt(0);
        number2 += number.charAt(1);
        int firstNumber = Integer.parseInt(number1);
        int secondNumber = Integer.parseInt(number2);
        int combinedNumber = firstNumber + secondNumber;
        return combinedNumber;

    }

    public static boolean lengthCheck(String creditCardString){
        int length = creditCardString.length();
        if (length > 12 && length < 17){
            return true;
        }
        return false;
    }

    public static boolean brandCheck(String creditCardString){
        String firstNumber = "";
        firstNumber += creditCardString.charAt(0);
        String firstTwoNumbers = "";
        firstTwoNumbers += creditCardString.charAt(0);
        firstTwoNumbers += creditCardString.charAt(1);

        if (firstNumber.equals("4") || firstNumber.equals("5") || firstNumber.equals("6")){
            return true;
        }
        if (firstTwoNumbers.equals("34") || firstTwoNumbers.equals("37")){
            return true;
        }
        return false;
    }
}