import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW10P01 {
    static int passwordLength;
    public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter a password: ");
        String userPassword = input.nextLine();
        passwordLength = userPassword.length();

        boolean length = passwordTotalLength(userPassword);
        boolean digits = passwordDigits(userPassword);
        boolean letters = passwordLetters(userPassword);
        boolean uppercase = passwordUppercase(userPassword);
        boolean specials = passwordSpecialCharacters(userPassword);

        if (length && digits && letters && uppercase && specials) {
            System.out.println();
            System.out.println("Password is valid and meets all requirements.");
        }
        else {
            System.out.println();
            System.out.println("Password is invalid.");
            if (!length) {
                System.out.println("Password must contain at least 13 characters.");
            }
            if (!digits) {
                System.out.println("Password must contain at least 4 digits.");
            }
            if (!letters) {
                System.out.println("Password must contain at least 7 letters.");
            }
            if (!uppercase) {
                System.out.println("Password must contain at least 3 uppercase letters.");
            }
            if (!specials) {
                System.out.println("Password must contain at least 2 non-alphanumeric characters.");
            }
        }

    }

    public static boolean passwordTotalLength(String userPassword){
        if (userPassword.length() >= 13){
            return true;
        }
        else{
            return false;
        }
    }

    public static boolean passwordDigits(String userPassword){
        int digits = 0;
        for (int i = 0; i < passwordLength; i++) {
            if ( Character.isDigit(userPassword.charAt(i)) ) {
                digits++;
            }
        }
        if (digits >= 4) {
            return true;
        }
        return false;
    }

    public static boolean passwordLetters(String userPassword){
        int letters = 0;
        for (int i = 0; i < passwordLength; i++){
            if ( Character.isLetter(userPassword.charAt(i)) ) {
                letters++;
            }
        }
        if (letters >= 7) {
            return true;
        }
        return false;
    }

    public static boolean passwordUppercase(String userPassword){
        int upperCaseLetters = 0;
        for (int i = 0; i < passwordLength; i++){
            if ( Character.isUpperCase(userPassword.charAt(i)) ) {
                upperCaseLetters++;
            }
        }
        if (upperCaseLetters >= 3){
            return true;
        }
        return false;
    }

    public static boolean passwordSpecialCharacters(String userPassword){
        int nonAlphanumeric = 0; 
        for (int i = 0; i < passwordLength; i++){
            if ( Character.isDigit(userPassword.charAt(i)) || Character.isLetter(userPassword.charAt(i)) ) {
                continue;
            }
            else {
                nonAlphanumeric++;
            }
        }
        if (nonAlphanumeric >= 2){
            return true;
        }
        return false;
    }
}