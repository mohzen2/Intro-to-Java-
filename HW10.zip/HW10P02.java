import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW10P02{
 	static Scanner input = new Scanner (System.in);
 	public static void main (String[] args) {
 		menu();
 	}

    public static void menu() {
        int userInput = 0;

        while (userInput != 3) {
        System.out.println();
        System.out.println("\n~~~ MENU ~~~ \n1. Display Prime Palindromes \n2. Display Mirroed Primes \n3. Exit Program ");
        userInput = input.nextInt();

        if (userInput == 1) {
            int n;
            System.out.print("How many prime palindromes would you like to display? ");
            n = input.nextInt();
            System.out.println();
            palindromeGenerator(n);
        }

        if (userInput == 2){
            int n;
            System.out.print("How many mirrored primes would you like to display? ");
            n = input.nextInt();
            System.out.println();
            mirrorPrimeGenerator(n);
        }

        }
    }

    public static void mirrorPrimeGenerator(int n) {
        int i = 1;
        int number = 2;

        while (i < n+1) {
            if (mirrorPrimeCheck(number)) {
                // here it is the opposite of the last time. we want to make sure its prime but not a palindrome.
                System.out.print(number + " ");
                if (i % 10 == 0){
                    System.out.println();
                }
                i++;

            }
            number++;

        }
    }

 	public static void palindromeGenerator(int n) {
        int i = 1;
        int number = 2;

        while (i < n+1) {
            if (isPalindrome(number) && primeCheck(number)){
                // checking palindrome first has a better runtime than calculating through the primes first. Since this is a short circut && operation
                System.out.print(number + " ");
                if (i % 10 == 0){
                    System.out.println();
                }
                i++;

            }
            number++;  
            
        }
 	}

    public static boolean mirrorPrimeCheck (int n) {
        String number = Integer.toString(n);
        String reversedNumber = reversedNumber(n);
        int reversedNumberInt = Integer.parseInt(reversedNumber);

        if(!isPalindrome(n) && primeCheck(n) && primeCheck(reversedNumberInt)) {
            return true;
        
        }
        return false;
    }

    public static boolean primeCheck (int n) {
        for (int i = 2; i <= (n/2); i++){
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean isPalindrome (int n) {
        String number = Integer.toString(n);
        String reversedNumber = reversedNumber(n);

        if (reversedNumber.equals(number)) {
            return true;
        }

        //System.out.print(number);
        return false;
    }

    public static String reversedNumber (int n) {
        String number = Integer.toString(n);
        String reversedNumber = "";

        for (int i = number.length(); i > 0; i--){
            reversedNumber += number.charAt(i-1);
        }

        return reversedNumber;
    }

 }