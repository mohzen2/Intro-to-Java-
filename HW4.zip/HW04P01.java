import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW04P01 {
 	public static void main (String[] args) {
 		Scanner input = new Scanner(System.in);

 		double userNumber;
 // Inputs 
 		System.out.print("Enter a floating point number: ");
 		userNumber = input.nextDouble();

 // Series of checks

 		// Is it zero
 		if (userNumber == 0.0) {
 			System.out.print("zero");
 		}

 		// Is it large, then check + or -
 		else if ( Math.abs(userNumber) > 1000000) {
	 		if (userNumber > 0) 
	 			{System.out.print("large, positive");}
	 		else
	 			{System.out.print("large, negative");}
 		}

 		// Is it small, then check + or -
 		else if (Math.abs(userNumber) < 1) {
 			if (userNumber > 0) {
 				System.out.print("small, positive");
 			}
 			else {
 				System.out.print("small, negative");
 			}
 		}

 		// The rest of the numbers, just check if + or -
 		else  {
 			if (userNumber > 0) {
 				System.out.print("positive");
 			}
 			else {
 				System.out.print ("negative");
 			}
 		}
 	}
 }