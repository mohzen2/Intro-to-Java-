import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW04P02 {
 	public static void main (String[] args) {

 		Scanner input = new Scanner(System.in);

 		// declaring variables

 		double a, b, c, discriminant, root1, root2;

 		System.out.print("Enter the a, b, and c values: ");

 		a = input.nextDouble();
 		b = input.nextDouble();
 		c = input.nextDouble();

 		// Calculations
 		discriminant = (b * b) - 4.0 * a * c;
 		root1 = (-b + Math.pow((discriminant),(1.0/2.0)))/ (2.0 * a);
 		root2 = (-b - Math.pow((discriminant),(1.0/2.0)))/ (2.0 * a);

        // Outputs
 		if (discriminant > 0) 
 			{System.out.print("The equation has two roots "+ root1 +" and " + root2);}
 		else if (discriminant < 0)
 			{ System.out.print("The equation has no real roots."); }
 		else 
 			{ System.out.println("The equation has one real root " + root1); }

 	}
 }