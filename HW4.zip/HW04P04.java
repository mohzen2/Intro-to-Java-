import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW04P04 {
 	public static void main (String[] Args)	{

 		// Declaring our date variables
 		Scanner input = new Scanner(System.in);
 		int currentDay, laterDay;

 		//Obtaining user input
 		System.out.print("Enter todays day (0-6): ");
 		currentDay = input.nextInt();
 		System.out.println();
 		System.out.print("Enter the number of days from today: ");
 		laterDay = ((input.nextInt() + currentDay) % 7);
 		System.out.println();

 		// logic loops
 		if (currentDay == 0) {
 			System.out.print("Today is Sunday");
 		}
 		else if (currentDay == 1) {
 			System.out.print("Today is Monday");
 		}
 		else if (currentDay == 2) {
 			System.out.print("Today is Tuesday");
 		}
 		else if (currentDay == 3) {
 			System.out.print("Today is Wednesday");
 		}
 		else if (currentDay == 4) {
 			System.out.print("Today is Thursday");
 		}
 		else if (currentDay == 5) {
 			System.out.print("Today is Friday");
 		}
 		else {
 			System.out.print("Today is Saturday");
 		}


 		if (laterDay == 0) {
 			System.out.print(" and the future day is Sunday.");
 		}
 		else if (laterDay == 1) {
 			System.out.print(" and the future day is Monday.");
 		}
 		else if (laterDay == 2) {
 			System.out.print(" and the future day is Tuesday.");
 		}
 		else if (laterDay == 3) {
 			System.out.print(" and the future day is Wednesday.");
 		}
 		else if (laterDay == 4) {
 			System.out.print(" and the future day is Thursday.");
 		}
 		else if (laterDay == 5) {
 			System.out.print(" and the future day is Friday.");
 		}
 		else {
 			System.out.print(" and the future day is Saturday.");
 		}



 	}
 }