/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

 public class HW04P03 {
 	public static void main (String[] args) {

 		// Declaring months and generating the random month
 		int randomMonth;
 		randomMonth = (int) (Math.random() * 12);
        randomMonth += 1;

        //Output
 		if (randomMonth == 1) {
 			System.out.print("January");
 		}
 		else if (randomMonth == 2) {
 			System.out.print("Febuary");
 		}
 		else if (randomMonth == 3) {
 			System.out.print("March");
 		}
 		else if (randomMonth == 4) {
 			System.out.print("April");
 		}
 		else if (randomMonth == 5) {
 			System.out.print("May");
 		}
 		else if (randomMonth == 6) {
 			System.out.print("June");
 		}
 		else if (randomMonth == 7) {
 			System.out.print("July");
 		}
 		else if (randomMonth == 8) {
 			System.out.print("August");
 		}
 		else if (randomMonth == 9) {
 			System.out.print("September");
 		}
 		else if (randomMonth == 10) {
 			System.out.print("October");
 		}
 		else if (randomMonth == 11) {
 			System.out.print("November");
 		}
 		else {
 			System.out.print("December");
 		}

 	}
 }