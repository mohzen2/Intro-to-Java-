import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW05P01 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

	// Declare variables and user inputs
		double costOfSoftware, totalCost;
		int quantitySoftwareSold;
		String payPrompt = "Total cost: $";


	// Gather inputs from user and check if its appropriate
		System.out.print("Enter the cost of the software: ");
		costOfSoftware = input.nextDouble();

		if (costOfSoftware < 0) {
			System.out.println("ERROR: Cost can not be negative, please put an appropriate value next time.");
			System.exit(1);
		}

		System.out.print("Enter the quantity sold: ");
		quantitySoftwareSold = input.nextInt();

		if (quantitySoftwareSold < 0) {
			System.out.println("ERROR: Quantity can not be negative, please put an appropriate value next time.");
			System.exit(1);
		}

	// Now if, if else statements to check for value amount and output total prive
		if (quantitySoftwareSold < 10) {
			System.out.print(payPrompt + (costOfSoftware * quantitySoftwareSold));
		}
		else if (quantitySoftwareSold >= 10 && quantitySoftwareSold < 20) {
			System.out.print(payPrompt + ((costOfSoftware * quantitySoftwareSold) * 0.8));
		}
		else if (quantitySoftwareSold >= 20 && quantitySoftwareSold < 50) {
			System.out.print(payPrompt + ((costOfSoftware * quantitySoftwareSold) * 0.7));
		}
		else if (quantitySoftwareSold >= 50 && quantitySoftwareSold < 100) {
			System.out.print(payPrompt + ((costOfSoftware * quantitySoftwareSold) * 0.6));
		}
		else {
			System.out.print(payPrompt + ((costOfSoftware * quantitySoftwareSold) * 0.5));
		}



	}
}