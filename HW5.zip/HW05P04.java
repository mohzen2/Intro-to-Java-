import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW05P04 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

// we must implement text and menu options as constants
		final String USER_MENU = 
		"1. Compute the Surface Area of a Sphere\n" +
		"2. Compute the Volume of a Sphere\n" +
		"3. Compute the Surface Area of a Rectangular Prism\n" +
		"4. Compute the Volume of a Rectangular Prism\n" +
		"5. Exit the program\n" +
		"\n" +
		"Please select from the menu: ";


		final String ERROR_TEXT = "Invalid input, please try again. Program now exiting ...";
		final String RADIUS_PROMPT = "Please enter the radius: ";
		final String LWH_PROMPT = "Please enter the length, width, and height: "; 


		final int SPHERE_SA = 1;
		final int SPHERE_VOL = 2;
		final int RECTANGLE_SA = 3;
		final int RECTANGLE_VOL = 4;
		final int EXIT = 5;

		System.out.print(USER_MENU);

// Gathering user input and checking validity of output
		int menuInput = input.nextInt();

		if (menuInput < 1 || menuInput > 5) {
			System.out.println(ERROR_TEXT);
			System.exit(1);
		}

// Math Formulas and switch
		double sphereSurfaceArea, sphereVolume, rectangleSurfaceArea, rectangleVolume, radius, length, width, height;

		switch (menuInput) {
			case SPHERE_SA:
				System.out.print(RADIUS_PROMPT);
				radius = input.nextDouble();
				if (radius < 0) {
					System.out.println(ERROR_TEXT);
					System.exit(1);
				}
				sphereSurfaceArea = (4 * Math.PI * (radius * radius));
				System.out.println("The area of the Sphere is: " + sphereSurfaceArea);
				break;

			case SPHERE_VOL:
				System.out.print(RADIUS_PROMPT);
				radius = input.nextDouble();
				if (radius < 0) {
					System.out.println(ERROR_TEXT);
					System.exit(1);
				}
				sphereVolume = ((4.0/3.0) * Math.PI * Math.pow(radius, 3.0));
				System.out.println("The volume of the Sphere is: " + sphereVolume);
				break;

			case RECTANGLE_SA:
				System.out.print(LWH_PROMPT);
				length = input.nextDouble();
				width = input.nextDouble();
				height = input.nextDouble();
				if (length < 0 || width < 0 || height < 0) {
					System.out.println(ERROR_TEXT);
					System.exit(1);
				}
				rectangleSurfaceArea = (2 * length * width) + (2 * height * width) + (2 * length * height);
				System.out.println("The surface area of the rectangular prism is: " + rectangleSurfaceArea);
				break;

			case RECTANGLE_VOL:
				System.out.print(LWH_PROMPT);
				length = input.nextDouble();
				width = input.nextDouble();
				height = input.nextDouble();
				if (length < 0 || width < 0 || height < 0) {
					System.out.println(ERROR_TEXT);
					System.exit(1);
				}
				rectangleVolume = (length * width * height);
				System.out.println("The volume of the rectangular prism is: " + rectangleVolume);
				break;

			case EXIT:
				System.out.println("Exiting the program now ...");
				break;

		}





	}
}