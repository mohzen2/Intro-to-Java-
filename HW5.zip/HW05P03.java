import java.util.Scanner;

/**
 * Name:        <Mohsen Alavian>
 * CIN:         <403241030>
 * Course:      <2011 Intro to programming>
 * Section:     <2011-05>
 * Description: <Introductory programming and principles with java>
 */

public class HW05P03 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);

		int userYear, userMonth, userDay;

// Gathering user inputs
		System.out.print("Enter year (i.e. 2023): ");
		userYear = input.nextInt();
		if (userYear < 0) {
			System.out.print("ERROR: Year must be a positive value. Program exiting now...");
			System.exit(1);
		}

// Here we make the changes in the user inputs if they choose jan or feb
		System.out.print("Enter month (1-12): ");
		userMonth = input.nextInt();
		if (userMonth < 0) {
			System.out.print("ERROR: Month must be a positive value. Program exiting now...");
			System.exit(1);
		}
		else if (userMonth > 12 || userMonth == 0) {
			System.out.print("ERROR: Please enter an appropriate month value. Program exiting now...");
			System.exit(1);
		}
		else if (userMonth == 1) {
			userMonth = 13;
			userYear -= 1;

		}
		else if (userMonth == 2) {
			userMonth = 14;
			userYear -= 1;
		}

		System.out.print("Enter the day of the month: ");
		userDay = input.nextInt();
		if (userDay < 0) {
			System.out.print("ERROR: Day must be a positive value. Program exiting now...");
			System.exit(1);
		}
		else if ( userDay > 31 || userDay == 0) {
			System.out.print("ERROR: Please enter an appropriate value for day. Program exiting now...");
			System.exit(1);
		}

// Calculations
		int zellerAlgo;
		zellerAlgo = (userDay + (26*(userMonth + 1)/ 10) + (userYear % 100) + ((userYear % 100)/4) + ((userYear / 100)/ 4) + (5 * (userYear/100))  ) % 7;

// Output & Switch Statement
		System.out.println();
		System.out.print("The day of the week is ");

		switch (zellerAlgo) {
			case 0: System.out.print("Saturday."); break;
			case 1: System.out.print("Sunday."); break;
			case 2: System.out.print("Monday."); break;
			case 3: System.out.print("Tuesday."); break;
			case 4: System.out.print("Wednesday."); break;
			case 5: System.out.print("Thursday."); break;
			case 6: System.out.print("Friday."); break;

		}

		System.out.println();

	}
}